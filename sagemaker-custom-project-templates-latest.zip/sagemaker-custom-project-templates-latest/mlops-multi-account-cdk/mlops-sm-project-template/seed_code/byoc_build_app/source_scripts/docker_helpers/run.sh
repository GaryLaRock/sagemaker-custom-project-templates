#!/bin/bash
echo "ready to execute"
Rscript /opt/ml/entrypoint.R $1
